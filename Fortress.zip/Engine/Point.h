#pragma once

class Point
{
public:
    Point();
    Point(float const x, float const y);

public:
    float x = 0.0f;
    float y = 0.0f;
};