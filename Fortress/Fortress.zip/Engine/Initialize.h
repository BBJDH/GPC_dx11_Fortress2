#pragma once

namespace Engine
{
    class Game * Initialize();
}