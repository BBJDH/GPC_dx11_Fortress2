#pragma once

namespace Engine::Time
{
    namespace Get
    {
        [[nodiscard]] float Elapsed();
        [[nodiscard]] float Delta  ();
    }
}